from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, SelectField, TextAreaField, FloatField, DateField, BooleanField
from wtforms.validators import DataRequired, Email, EqualTo, ValidationError, Length, Optional
from models import User

class LoginForm(FlaskForm):
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired()])
    submit = SubmitField('Login')

class RegistrationForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired(), Length(min=3, max=64)])
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired(), Length(min=8)])
    confirm_password = PasswordField('Confirm Password', validators=[DataRequired(), EqualTo('password')])
    first_name = StringField('First Name', validators=[DataRequired(), Length(max=100)])
    last_name = StringField('Last Name', validators=[DataRequired(), Length(max=100)])
    role = SelectField('Role', choices=[('student', 'Student'), ('teacher', 'Teacher'), ('admin', 'Administrator')])
    submit = SubmitField('Register')
    
    def validate_username(self, username):
        user = User.query.filter_by(username=username.data).first()
        if user:
            raise ValidationError('That username is already taken. Please choose another one.')
            
    def validate_email(self, email):
        user = User.query.filter_by(email=email.data).first()
        if user:
            raise ValidationError('That email is already registered. Please use another one.')

class CourseForm(FlaskForm):
    code = StringField('Course Code', validators=[DataRequired(), Length(max=20)])
    title = StringField('Course Title', validators=[DataRequired(), Length(max=100)])
    description = TextAreaField('Description', validators=[Optional()])
    credits = StringField('Credits', validators=[DataRequired()])
    teacher = SelectField('Teacher', validators=[Optional()], coerce=int)
    submit = SubmitField('Submit')

class GradeForm(FlaskForm):
    student = SelectField('Student', validators=[DataRequired()], coerce=int)
    course = SelectField('Course', validators=[DataRequired()], coerce=int)
    assignment_name = StringField('Assignment Name', validators=[DataRequired(), Length(max=100)])
    score = FloatField('Score', validators=[DataRequired()])
    max_score = FloatField('Maximum Score', validators=[DataRequired()])
    weight = FloatField('Weight', validators=[DataRequired()])
    submit = SubmitField('Submit Grade')

class AttendanceSessionForm(FlaskForm):
    course = SelectField('Course', validators=[DataRequired()], coerce=int)
    date = DateField('Date', validators=[DataRequired()])
    description = StringField('Description', validators=[Optional(), Length(max=200)])
    submit = SubmitField('Create Attendance Session')

class AttendanceRecordForm(FlaskForm):
    status = SelectField('Status', choices=[
        ('present', 'Present'),
        ('absent', 'Absent'),
        ('excused', 'Excused'),
        ('late', 'Late')
    ], validators=[DataRequired()])
    note = StringField('Note', validators=[Optional(), Length(max=200)])
    submit = SubmitField('Save')

class ProfileForm(FlaskForm):
    first_name = StringField('First Name', validators=[DataRequired(), Length(max=100)])
    last_name = StringField('Last Name', validators=[DataRequired(), Length(max=100)])
    email = StringField('Email', validators=[DataRequired(), Email()])
    username = StringField('Username', validators=[DataRequired(), Length(min=3, max=64)])
    submit = SubmitField('Update Profile')

class PasswordChangeForm(FlaskForm):
    current_password = PasswordField('Current Password', validators=[DataRequired()])
    new_password = PasswordField('New Password', validators=[DataRequired(), Length(min=8)])
    confirm_password = PasswordField('Confirm New Password', validators=[DataRequired(), EqualTo('new_password')])
    submit = SubmitField('Change Password')

class EnrollmentForm(FlaskForm):
    course = SelectField('Course', validators=[DataRequired()], coerce=int)
    submit = SubmitField('Enroll')
    
class AdminPasswordResetForm(FlaskForm):
    new_password = PasswordField('New Password', validators=[DataRequired(), Length(min=8)])
    confirm_password = PasswordField('Confirm New Password', validators=[DataRequired(), EqualTo('new_password')])
    submit = SubmitField('Reset Password')
    
class AdminEnrollmentForm(FlaskForm):
    student = SelectField('Student', validators=[DataRequired()], coerce=int)
    course = SelectField('Course', validators=[DataRequired()], coerce=int)
    submit = SubmitField('Enroll Student')
