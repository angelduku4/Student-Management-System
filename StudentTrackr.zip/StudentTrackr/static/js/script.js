/**
 * Student Management System - Main JavaScript
 * This file contains general functionality used across the application
 */

document.addEventListener('DOMContentLoaded', function() {
    // Handle notifications
    initializeNotifications();

    // Set up any tooltips
    initializeTooltips();

    // Automatic alert dismissal
    setupAlertDismissal();
});

/**
 * Initialize notifications functionality
 */
function initializeNotifications() {
    const showNotificationsBtn = document.getElementById('showNotifications');
    if (!showNotificationsBtn) return;

    const notificationBadge = document.querySelector('.notification-badge');
    const notificationBadgeMenu = document.querySelector('.notification-badge-menu');
    const notificationsModal = new bootstrap.Modal(document.getElementById('notificationsModal'));
    const notificationsContainer = document.getElementById('notifications-container');
    const notificationsList = document.querySelector('.notifications-list');
    const notificationsLoading = document.querySelector('.notifications-loading');
    const notificationsEmpty = document.querySelector('.notifications-empty');
    
    // Show notifications when clicked
    showNotificationsBtn.addEventListener('click', function(e) {
        e.preventDefault();
        
        // Show the modal
        notificationsModal.show();
        
        // Fetch notifications
        fetchNotifications();
    });
    
    // Function to fetch notifications
    function fetchNotifications() {
        // Show loading
        notificationsLoading.classList.remove('d-none');
        notificationsList.innerHTML = '';
        notificationsEmpty.classList.add('d-none');
        
        // Fetch from API
        fetch('/notifications')
            .then(response => response.json())
            .then(data => {
                // Hide loading
                notificationsLoading.classList.add('d-none');
                
                // Update UI
                if (data.length > 0) {
                    data.forEach(notification => {
                        const notificationItem = document.createElement('div');
                        notificationItem.className = 'notification-item p-3 border-bottom';
                        notificationItem.innerHTML = `
                            <div class="d-flex justify-content-between">
                                <span class="small text-muted">${notification.timestamp}</span>
                                <button class="btn btn-sm text-muted p-0 mark-read" data-id="${notification.id}">
                                    <i class="fas fa-times"></i>
                                </button>
                            </div>
                            <p class="mb-0">${notification.message}</p>
                        `;
                        notificationsList.appendChild(notificationItem);
                        
                        // Add event listener to mark as read
                        const markReadBtn = notificationItem.querySelector('.mark-read');
                        markReadBtn.addEventListener('click', function() {
                            markNotificationAsRead(notification.id, notificationItem);
                        });
                    });
                    
                    // Update notification count
                    updateNotificationCount(data.length);
                } else {
                    notificationsEmpty.classList.remove('d-none');
                    updateNotificationCount(0);
                }
            })
            .catch(error => {
                console.error('Error fetching notifications:', error);
                notificationsLoading.classList.add('d-none');
                notificationsList.innerHTML = `
                    <div class="text-center py-4 text-danger">
                        <i class="fas fa-exclamation-circle fa-3x mb-3"></i>
                        <p>Failed to load notifications. Please try again.</p>
                    </div>
                `;
            });
    }
    
    // Function to mark notification as read
    function markNotificationAsRead(id, element) {
        fetch(`/notifications/mark-read/${id}`, {
            method: 'POST'
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Remove the notification from the list
                element.remove();
                
                // Update count
                const remainingNotifications = notificationsList.querySelectorAll('.notification-item').length;
                updateNotificationCount(remainingNotifications);
                
                // Show empty message if no notifications left
                if (remainingNotifications === 0) {
                    notificationsEmpty.classList.remove('d-none');
                }
            }
        })
        .catch(error => {
            console.error('Error marking notification as read:', error);
        });
    }
    
    // Function to update notification count
    function updateNotificationCount(count) {
        if (count > 0) {
            notificationBadge.textContent = count;
            notificationBadge.classList.remove('d-none');
            notificationBadgeMenu.textContent = count;
            notificationBadgeMenu.classList.remove('d-none');
        } else {
            notificationBadge.classList.add('d-none');
            notificationBadgeMenu.classList.add('d-none');
        }
    }
    
    // Check for notifications every 30 seconds
    setInterval(function() {
        fetch('/notifications')
            .then(response => response.json())
            .then(data => {
                updateNotificationCount(data.length);
            })
            .catch(error => {
                console.error('Error checking notifications:', error);
            });
    }, 30000);
    
    // Initial check for notifications
    fetch('/notifications')
        .then(response => response.json())
        .then(data => {
            updateNotificationCount(data.length);
        })
        .catch(error => {
            console.error('Error checking notifications:', error);
        });
}

/**
 * Initialize tooltips using Bootstrap
 */
function initializeTooltips() {
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function(tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
}

/**
 * Set up automatic dismissal of alerts after 5 seconds
 */
function setupAlertDismissal() {
    const alerts = document.querySelectorAll('.alert:not(.alert-danger)');
    alerts.forEach(alert => {
        setTimeout(() => {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }, 5000);
    });
}

/**
 * Format a date string (YYYY-MM-DD) to a more readable format
 */
function formatDate(dateString) {
    const options = { year: 'numeric', month: 'long', day: 'numeric' };
    return new Date(dateString).toLocaleDateString(undefined, options);
}

/**
 * Format a percentage with one decimal place and % symbol
 */
function formatPercentage(value) {
    return parseFloat(value).toFixed(1) + '%';
}

/**
 * Get a color based on percentage value (for grades, attendance, etc.)
 */
function getColorForPercentage(percentage) {
    if (percentage >= 90) return 'success';
    if (percentage >= 80) return 'primary';
    if (percentage >= 70) return 'info';
    if (percentage >= 60) return 'warning';
    return 'danger';
}
