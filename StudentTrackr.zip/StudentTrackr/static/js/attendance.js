/**
 * Student Management System - Attendance Management
 * This file contains JavaScript functionality for the attendance management pages
 */

document.addEventListener('DOMContentLoaded', function() {
    // Filter attendance sessions by course
    const filterCourse = document.getElementById('filterCourse');
    if (filterCourse) {
        filterCourse.addEventListener('change', filterAttendanceSessions);
    }

    // Get URL parameters if any
    const urlParams = new URLSearchParams(window.location.search);
    const courseId = urlParams.get('course_id');
    const studentId = urlParams.get('student_id');

    // If we have params, set the filters
    if (courseId && filterCourse) {
        filterCourse.value = courseId;
        filterAttendanceSessions();
    }
});

/**
 * Filter the attendance sessions table by course
 */
function filterAttendanceSessions() {
    const filterValue = document.getElementById('filterCourse').value;
    const rows = document.querySelectorAll('#sessionsTable tbody tr');
    
    rows.forEach(row => {
        const courseId = row.getAttribute('data-course-id');
        
        if (filterValue === '' || courseId === filterValue) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
}

/**
 * Update status color based on the selected value
 */
function updateStatusColor(select) {
    // Remove existing classes
    select.classList.remove('bg-success-subtle', 'bg-danger-subtle', 'bg-warning-subtle', 'bg-info-subtle');
    
    // Add appropriate class based on value
    if (select.value === 'present') {
        select.classList.add('bg-success-subtle');
    } else if (select.value === 'absent') {
        select.classList.add('bg-danger-subtle');
    } else if (select.value === 'late') {
        select.classList.add('bg-warning-subtle');
    } else if (select.value === 'excused') {
        select.classList.add('bg-info-subtle');
    }
}

/**
 * Save an attendance record via AJAX
 */
function saveAttendanceRecord(attendanceId, status, note, button, successIcon) {
    // Disable the button and show loading state
    button.disabled = true;
    button.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Saving...';
    
    // Make the AJAX request
    fetch('/teacher/attendance/update', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams({
            'attendance_id': attendanceId,
            'status': status,
            'note': note
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Show success icon
            button.classList.add('d-none');
            successIcon.classList.remove('d-none');
            
            // Hide success icon after 3 seconds
            setTimeout(() => {
                button.innerHTML = '<i class="fas fa-save me-1"></i>Save';
                button.disabled = false;
                button.classList.remove('d-none');
                successIcon.classList.add('d-none');
            }, 3000);
        } else {
            // Show error
            alert('Failed to update attendance: ' + (data.error || 'Unknown error'));
            button.innerHTML = '<i class="fas fa-save me-1"></i>Save';
            button.disabled = false;
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('An error occurred while updating attendance.');
        button.innerHTML = '<i class="fas fa-save me-1"></i>Save';
        button.disabled = false;
    });
}

/**
 * Initialize the attendance detail page
 */
function initAttendanceDetailPage() {
    // Save attendance records
    document.querySelectorAll('.save-attendance').forEach(button => {
        button.addEventListener('click', function() {
            const attendanceId = this.getAttribute('data-attendance-id');
            const statusSelect = document.querySelector(`.attendance-status[data-attendance-id="${attendanceId}"]`);
            const noteInput = document.querySelector(`.attendance-note[data-attendance-id="${attendanceId}"]`);
            const successIcon = document.querySelector(`.save-success[data-attendance-id="${attendanceId}"]`);
            
            // Get the values
            const status = statusSelect.value;
            const note = noteInput.value;
            
            // Save the record
            saveAttendanceRecord(attendanceId, status, note, this, successIcon);
        });
    });
    
    // Change attendance status color based on selection
    document.querySelectorAll('.attendance-status').forEach(select => {
        // Set initial color
        updateStatusColor(select);
        
        // Update color on change
        select.addEventListener('change', function() {
            updateStatusColor(this);
        });
    });
}

// If we're on the attendance detail page, initialize it
if (document.querySelector('.save-attendance')) {
    initAttendanceDetailPage();
}
