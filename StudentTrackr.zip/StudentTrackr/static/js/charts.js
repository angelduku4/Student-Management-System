/**
 * Student Management System - Charts and Visualizations
 * This file contains functions for creating charts and visualizations
 * using Chart.js library
 */

/**
 * Create a grade distribution chart
 * @param {string} elementId - The ID of the canvas element
 * @param {Object} data - The grade data (labels and values)
 */
function createGradeDistributionChart(elementId, data) {
    const ctx = document.getElementById(elementId).getContext('2d');
    return new Chart(ctx, {
        type: 'bar',
        data: {
            labels: data.labels,
            datasets: [{
                label: 'Course Average (%)',
                data: data.values,
                backgroundColor: 'rgba(78, 115, 223, 0.7)',
                borderColor: 'rgba(78, 115, 223, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    ticks: {
                        callback: function(value) {
                            return value + '%';
                        }
                    }
                }
            }
        }
    });
}

/**
 * Create an attendance pie chart
 * @param {string} elementId - The ID of the canvas element
 * @param {Object} data - The attendance data
 */
function createAttendancePieChart(elementId, data) {
    const ctx = document.getElementById(elementId).getContext('2d');
    return new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Present', 'Absent', 'Late', 'Excused'],
            datasets: [{
                data: [
                    data.present,
                    data.absent,
                    data.late,
                    data.excused
                ],
                backgroundColor: [
                    'rgba(40, 167, 69, 0.7)',  // green
                    'rgba(220, 53, 69, 0.7)',  // red
                    'rgba(255, 193, 7, 0.7)',  // yellow
                    'rgba(23, 162, 184, 0.7)'  // cyan
                ],
                borderColor: [
                    'rgba(40, 167, 69, 1)',
                    'rgba(220, 53, 69, 1)',
                    'rgba(255, 193, 7, 1)',
                    'rgba(23, 162, 184, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'right'
                }
            }
        }
    });
}

/**
 * Create a radar chart for grade distribution
 * @param {string} elementId - The ID of the canvas element
 * @param {Object} data - The course data (labels and values)
 */
function createGradeRadarChart(elementId, data) {
    const ctx = document.getElementById(elementId).getContext('2d');
    return new Chart(ctx, {
        type: 'radar',
        data: {
            labels: data.labels,
            datasets: [{
                label: 'Course Averages',
                data: data.values,
                backgroundColor: 'rgba(78, 115, 223, 0.2)',
                borderColor: 'rgba(78, 115, 223, 1)',
                pointBackgroundColor: 'rgba(78, 115, 223, 1)',
                pointBorderColor: '#fff',
                pointHoverBackgroundColor: '#fff',
                pointHoverBorderColor: 'rgba(78, 115, 223, 1)',
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            scales: {
                r: {
                    angleLines: {
                        display: true
                    },
                    suggestedMin: 0,
                    suggestedMax: 100
                }
            }
        }
    });
}

/**
 * Create a bar chart for enrollment statistics
 * @param {string} elementId - The ID of the canvas element
 * @param {Object} data - The enrollment data (labels and values)
 */
function createEnrollmentChart(elementId, data) {
    const ctx = document.getElementById(elementId).getContext('2d');
    return new Chart(ctx, {
        type: 'bar',
        data: {
            labels: data.labels,
            datasets: [{
                label: 'Students Enrolled',
                data: data.values,
                backgroundColor: 'rgba(78, 115, 223, 0.7)',
                borderColor: 'rgba(78, 115, 223, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        precision: 0
                    }
                }
            }
        }
    });
}

/**
 * Create a doughnut chart for user distribution (admin dashboard)
 * @param {string} elementId - The ID of the canvas element
 * @param {Object} data - The user data (counts)
 */
function createUserDistributionChart(elementId, data) {
    const ctx = document.getElementById(elementId).getContext('2d');
    return new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Students', 'Teachers', 'Administrators'],
            datasets: [{
                data: [data.students, data.teachers, data.admins],
                backgroundColor: [
                    'rgba(78, 115, 223, 0.7)',   // primary
                    'rgba(40, 167, 69, 0.7)',    // success
                    'rgba(220, 53, 69, 0.7)'     // danger
                ],
                borderColor: [
                    'rgba(78, 115, 223, 1)',
                    'rgba(40, 167, 69, 1)',
                    'rgba(220, 53, 69, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom'
                },
                title: {
                    display: true,
                    text: 'User Distribution'
                }
            }
        }
    });
}

/**
 * Create a line chart for grade trends over time
 * @param {string} elementId - The ID of the canvas element
 * @param {Object} data - The grade trend data (dates and averages)
 */
function createGradeTrendChart(elementId, data) {
    const ctx = document.getElementById(elementId).getContext('2d');
    return new Chart(ctx, {
        type: 'line',
        data: {
            labels: data.dates,
            datasets: [{
                label: 'Average Grade (%)',
                data: data.averages,
                backgroundColor: 'rgba(78, 115, 223, 0.1)',
                borderColor: 'rgba(78, 115, 223, 1)',
                borderWidth: 2,
                fill: true,
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    ticks: {
                        callback: function(value) {
                            return value + '%';
                        }
                    }
                }
            }
        }
    });
}
