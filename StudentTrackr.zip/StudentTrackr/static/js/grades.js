/**
 * Student Management System - Grades Management
 * This file contains JavaScript functionality for the grades management pages
 */

document.addEventListener('DOMContentLoaded', function() {
    // Course dropdown change handler - fetch students for the selected course
    const courseDropdown = document.getElementById('course');
    if (courseDropdown) {
        courseDropdown.addEventListener('change', fetchStudentsForCourse);
    }

    // Filter grades by course and student
    const filterCourse = document.getElementById('filterCourse');
    const filterStudent = document.getElementById('filterStudent');
    
    if (filterCourse) {
        filterCourse.addEventListener('change', filterGrades);
    }
    
    if (filterStudent) {
        filterStudent.addEventListener('change', filterGrades);
    }

    // Get URL parameters if any
    const urlParams = new URLSearchParams(window.location.search);
    const courseId = urlParams.get('course_id');
    const studentId = urlParams.get('student_id');

    // If we have course_id and student_id in URL, pre-select them in the form
    if (courseId && courseDropdown) {
        courseDropdown.value = courseId;
        fetchStudentsForCourse().then(() => {
            const studentDropdown = document.getElementById('student');
            if (studentId && studentDropdown) {
                studentDropdown.value = studentId;
            }
        });
    }

    // If we have filters in URL, apply them
    if (courseId && filterCourse) {
        filterCourse.value = courseId;
        filterGrades();
    }

    if (studentId && filterStudent) {
        filterStudent.value = studentId;
        filterGrades();
    }
});

/**
 * Fetch students enrolled in the selected course
 */
async function fetchStudentsForCourse() {
    const courseId = document.getElementById('course').value;
    const studentDropdown = document.getElementById('student');
    
    if (!courseId || !studentDropdown) return;
    
    // Save the currently selected student if any
    const currentSelectedStudent = studentDropdown.value;
    
    // Clear all current options
    while (studentDropdown.options.length > 0) {
        studentDropdown.remove(0);
    }
    
    // Show loading state
    studentDropdown.disabled = true;
    const loadingOption = document.createElement('option');
    loadingOption.text = 'Loading students...';
    studentDropdown.add(loadingOption);
    
    try {
        const response = await fetch(`/get_students/${courseId}`);
        const students = await response.json();
        
        // Remove loading option
        studentDropdown.remove(0);
        
        if (students.error) {
            const errorOption = document.createElement('option');
            errorOption.text = 'Error loading students';
            errorOption.value = 0;
            studentDropdown.add(errorOption);
        } else if (students.length === 0) {
            const noStudentsOption = document.createElement('option');
            noStudentsOption.text = 'No students enrolled';
            noStudentsOption.value = 0;
            studentDropdown.add(noStudentsOption);
        } else {
            // Add students to dropdown
            students.forEach(student => {
                const option = document.createElement('option');
                option.value = student.id;
                option.text = student.name;
                studentDropdown.add(option);
                
                // Re-select the previously selected student if it exists in the new list
                if (option.value === currentSelectedStudent) {
                    option.selected = true;
                }
            });
        }
    } catch (error) {
        console.error('Error fetching students:', error);
        const errorOption = document.createElement('option');
        errorOption.text = 'Error loading students';
        errorOption.value = 0;
        studentDropdown.add(errorOption);
    } finally {
        studentDropdown.disabled = false;
    }
    
    return studentDropdown;
}

/**
 * Filter grades by course and student
 */
function filterGrades() {
    const courseFilter = document.getElementById('filterCourse').value;
    const studentFilter = document.getElementById('filterStudent').value;
    const rows = document.querySelectorAll('#gradesTable tbody tr');
    
    rows.forEach(row => {
        const rowCourseId = row.getAttribute('data-course-id');
        const rowStudentId = row.getAttribute('data-student-id');
        const courseMatch = !courseFilter || rowCourseId === courseFilter;
        const studentMatch = !studentFilter || rowStudentId === studentFilter;
        
        if (courseMatch && studentMatch) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
}

/**
 * Calculate percentage from score and max score
 */
function calculatePercentage(score, maxScore) {
    return (parseFloat(score) / parseFloat(maxScore) * 100).toFixed(1) + '%';
}

/**
 * Validate grade form before submission
 */
function validateGradeForm() {
    const form = document.getElementById('gradeForm');
    const score = parseFloat(document.getElementById('score').value);
    const maxScore = parseFloat(document.getElementById('max_score').value);
    const weight = parseFloat(document.getElementById('weight').value);
    
    let isValid = true;
    let errorMessage = '';
    
    if (isNaN(score) || score < 0) {
        errorMessage += 'Score must be a positive number.\n';
        isValid = false;
    }
    
    if (isNaN(maxScore) || maxScore <= 0) {
        errorMessage += 'Maximum score must be greater than zero.\n';
        isValid = false;
    }
    
    if (score > maxScore) {
        errorMessage += 'Score cannot be greater than maximum score.\n';
        isValid = false;
    }
    
    if (isNaN(weight) || weight <= 0) {
        errorMessage += 'Weight must be greater than zero.\n';
        isValid = false;
    }
    
    if (!isValid) {
        alert(errorMessage);
        return false;
    }
    
    return true;
}

// Add form validation if the grade form exists
const gradeForm = document.getElementById('gradeForm');
if (gradeForm) {
    gradeForm.addEventListener('submit', function(event) {
        if (!validateGradeForm()) {
            event.preventDefault();
        }
    });
}
