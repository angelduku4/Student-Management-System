from app import db
from flask_login import UserMixin
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash

# Association table for student-course relationship (many-to-many)
student_course = db.Table(
    'student_course',
    db.Column('student_id', db.Integer, db.ForeignKey('user.id'), primary_key=True),
    db.Column('course_id', db.Integer, db.ForeignKey('course.id'), primary_key=True)
)

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    first_name = db.Column(db.String(100), nullable=False)
    last_name = db.Column(db.String(100), nullable=False)
    role = db.Column(db.String(20), nullable=False)  # 'admin', 'teacher', or 'student'
    date_registered = db.Column(db.DateTime, default=datetime.utcnow)
    profile_pic = db.Column(db.String(100), default='default.jpg')
    
    # Relationships
    # For students: courses they are enrolled in
    enrolled_courses = db.relationship('Course', secondary=student_course, backref='enrolled_students')
    # For students: their grades
    grades = db.relationship('Grade', backref='student', lazy=True, foreign_keys='Grade.student_id')
    # For students: their attendance records
    attendance_records = db.relationship('Attendance', backref='student', lazy=True)
    # For teachers: courses they teach
    courses_teaching = db.relationship('Course', backref='teacher', lazy=True)
    # For all: notifications they've received
    notifications = db.relationship('Notification', backref='recipient', lazy=True)
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    def get_full_name(self):
        return f"{self.first_name} {self.last_name}"
    
    def __repr__(self):
        return f"<User {self.username}>"

class Course(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    code = db.Column(db.String(20), unique=True, nullable=False)
    title = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=True)
    credits = db.Column(db.Integer, default=3)
    teacher_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    
    # Relationships
    grades = db.relationship('Grade', backref='course', lazy=True)
    attendance_sessions = db.relationship('AttendanceSession', backref='course', lazy=True)
    
    def __repr__(self):
        return f"<Course {self.code}: {self.title}>"

class Grade(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    course_id = db.Column(db.Integer, db.ForeignKey('course.id'), nullable=False)
    assignment_name = db.Column(db.String(100), nullable=False)
    score = db.Column(db.Float, nullable=False)
    max_score = db.Column(db.Float, nullable=False)
    weight = db.Column(db.Float, default=1.0)  # Weight of this grade in the final course grade
    date_added = db.Column(db.DateTime, default=datetime.utcnow)
    
    def get_percentage(self):
        return (self.score / self.max_score) * 100
    
    def __repr__(self):
        return f"<Grade {self.student_id} {self.course_id} {self.assignment_name}: {self.score}/{self.max_score}>"

class AttendanceSession(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    course_id = db.Column(db.Integer, db.ForeignKey('course.id'), nullable=False)
    date = db.Column(db.Date, nullable=False)
    description = db.Column(db.String(200), nullable=True)
    
    # Relationship to individual attendance records
    records = db.relationship('Attendance', backref='session', lazy=True)
    
    def __repr__(self):
        return f"<AttendanceSession {self.course_id} {self.date}>"

class Attendance(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    session_id = db.Column(db.Integer, db.ForeignKey('attendance_session.id'), nullable=False)
    student_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    status = db.Column(db.String(20), nullable=False, default='present')  # 'present', 'absent', 'excused', 'late'
    note = db.Column(db.String(200), nullable=True)
    
    def __repr__(self):
        return f"<Attendance {self.student_id} {self.session_id}: {self.status}>"

class Notification(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    message = db.Column(db.Text, nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    is_read = db.Column(db.Boolean, default=False)
    
    def __repr__(self):
        return f"<Notification {self.user_id}: {self.message[:20]}...>"
