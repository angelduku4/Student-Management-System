from flask import render_template, flash, redirect, url_for, request, jsonify, abort
from flask_login import login_user, logout_user, current_user, login_required
from werkzeug.security import generate_password_hash, check_password_hash
from app import db
from models import User, Course, Grade, AttendanceSession, Attendance, Notification, student_course
from forms import (LoginForm, RegistrationForm, CourseForm, GradeForm, 
                   AttendanceSessionForm, AttendanceRecordForm, ProfileForm, 
                   PasswordChangeForm, EnrollmentForm, AdminPasswordResetForm,
                   AdminEnrollmentForm)
from functools import wraps
from datetime import datetime

def register_routes(app):
    
    # Role-based access decorators
    def admin_required(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if not current_user.is_authenticated or current_user.role != 'admin':
                flash('You do not have permission to access this page.', 'danger')
                return redirect(url_for('login'))
            return f(*args, **kwargs)
        return decorated_function

    def teacher_required(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if not current_user.is_authenticated or current_user.role not in ['teacher', 'admin']:
                flash('You do not have permission to access this page.', 'danger')
                return redirect(url_for('login'))
            return f(*args, **kwargs)
        return decorated_function

    def student_required(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if not current_user.is_authenticated or current_user.role != 'student':
                flash('You do not have permission to access this page.', 'danger')
                return redirect(url_for('login'))
            return f(*args, **kwargs)
        return decorated_function

    # Helper Functions
    def create_notification(user_id, message):
        notification = Notification(user_id=user_id, message=message)
        db.session.add(notification)
        db.session.commit()

    # Home Page Route
    @app.route('/')
    def index():
        return render_template('index.html', title='Student Management System')

    # Authentication Routes
    @app.route('/login', methods=['GET', 'POST'])
    def login():
        if current_user.is_authenticated:
            return redirect(url_for('dashboard'))
        
        form = LoginForm()
        if form.validate_on_submit():
            user = User.query.filter_by(email=form.email.data).first()
            if user and user.check_password(form.password.data):
                login_user(user)
                flash(f'Welcome back, {user.first_name}!', 'success')
                next_page = request.args.get('next')
                return redirect(next_page if next_page else url_for('dashboard'))
            else:
                flash('Login unsuccessful. Please check email and password.', 'danger')
        
        return render_template('login.html', title='Login', form=form)

    @app.route('/register', methods=['GET', 'POST'])
    def register():
        if current_user.is_authenticated:
            return redirect(url_for('dashboard'))
        
        form = RegistrationForm()
        if form.validate_on_submit():
            user = User(
                username=form.username.data,
                email=form.email.data,
                first_name=form.first_name.data,
                last_name=form.last_name.data,
                role=form.role.data
            )
            user.set_password(form.password.data)
            
            db.session.add(user)
            db.session.commit()
            
            flash(f'Account created for {form.first_name.data}! You can now log in.', 'success')
            return redirect(url_for('login'))
        
        return render_template('register.html', title='Register', form=form)

    @app.route('/logout')
    def logout():
        logout_user()
        flash('You have been logged out.', 'info')
        return redirect(url_for('index'))

    # Dashboard Routes
    @app.route('/dashboard')
    @login_required
    def dashboard():
        if current_user.role == 'student':
            enrolled_courses = current_user.enrolled_courses
            grades = Grade.query.filter_by(student_id=current_user.id).all()
            attendance_records = Attendance.query.filter_by(student_id=current_user.id).all()
            
            # Calculate course averages
            course_averages = {}
            for course in enrolled_courses:
                course_grades = [g for g in grades if g.course_id == course.id]
                if course_grades:
                    total_weighted_score = sum(g.score / g.max_score * g.weight for g in course_grades)
                    total_weight = sum(g.weight for g in course_grades)
                    if total_weight > 0:
                        course_averages[course.id] = (total_weighted_score / total_weight) * 100
                    else:
                        course_averages[course.id] = 0
                else:
                    course_averages[course.id] = 0
            
            # Calculate attendance statistics
            attendance_stats = {
                'present': len([a for a in attendance_records if a.status == 'present']),
                'absent': len([a for a in attendance_records if a.status == 'absent']),
                'excused': len([a for a in attendance_records if a.status == 'excused']),
                'late': len([a for a in attendance_records if a.status == 'late'])
            }
            
            return render_template('student/dashboard.html', 
                                 title='Student Dashboard',
                                 courses=enrolled_courses,
                                 course_averages=course_averages,
                                 attendance_stats=attendance_stats)
        
        elif current_user.role == 'teacher':
            teaching_courses = current_user.courses_teaching
            student_counts = {course.id: len(course.enrolled_students) for course in teaching_courses}
            
            # Get recent grades given
            recent_grades = Grade.query.join(Course).filter(Course.teacher_id == current_user.id).order_by(Grade.date_added.desc()).limit(5).all()
            
            # Get recent attendance sessions
            recent_attendance = AttendanceSession.query.join(Course).filter(Course.teacher_id == current_user.id).order_by(AttendanceSession.date.desc()).limit(5).all()
            
            return render_template('teacher/dashboard.html',
                                 title='Teacher Dashboard',
                                 courses=teaching_courses,
                                 student_counts=student_counts,
                                 recent_grades=recent_grades,
                                 recent_attendance=recent_attendance)
        
        elif current_user.role == 'admin':
            student_count = User.query.filter_by(role='student').count()
            teacher_count = User.query.filter_by(role='teacher').count()
            course_count = Course.query.count()
            
            # Get recent users
            recent_users = User.query.order_by(User.date_registered.desc()).limit(5).all()
            
            return render_template('admin/dashboard.html',
                                 title='Admin Dashboard',
                                 student_count=student_count,
                                 teacher_count=teacher_count,
                                 course_count=course_count,
                                 recent_users=recent_users)

    # Student Routes
    @app.route('/student/courses')
    @login_required
    @student_required
    def student_courses():
        enrolled_courses = current_user.enrolled_courses
        available_courses = Course.query.filter(~Course.id.in_([course.id for course in enrolled_courses])).all()
        
        form = EnrollmentForm()
        form.course.choices = [(c.id, f"{c.code} - {c.title}") for c in available_courses]
        
        return render_template('student/courses.html',
                             title='My Courses',
                             enrolled_courses=enrolled_courses,
                             form=form)

    @app.route('/student/enroll', methods=['POST'])
    @login_required
    @student_required
    def enroll_course():
        form = EnrollmentForm()
        available_courses = Course.query.filter(~Course.id.in_([c.id for c in current_user.enrolled_courses])).all()
        form.course.choices = [(c.id, f"{c.code} - {c.title}") for c in available_courses]
        
        if form.validate_on_submit():
            course = Course.query.get_or_404(form.course.data)
            
            if course in current_user.enrolled_courses:
                flash(f'You are already enrolled in {course.title}', 'warning')
            else:
                current_user.enrolled_courses.append(course)
                db.session.commit()
                flash(f'Successfully enrolled in {course.title}', 'success')
                
                # Create notification for the teacher
                if course.teacher_id:
                    create_notification(
                        course.teacher_id, 
                        f"Student {current_user.get_full_name()} has enrolled in your course {course.title}"
                    )
        
        return redirect(url_for('student_courses'))

    @app.route('/student/drop/<int:course_id>', methods=['POST'])
    @login_required
    @student_required
    def drop_course(course_id):
        course = Course.query.get_or_404(course_id)
        
        if course in current_user.enrolled_courses:
            current_user.enrolled_courses.remove(course)
            db.session.commit()
            flash(f'You have dropped {course.title}', 'success')
            
            # Create notification for the teacher
            if course.teacher_id:
                create_notification(
                    course.teacher_id, 
                    f"Student {current_user.get_full_name()} has dropped your course {course.title}"
                )
        else:
            flash(f'You are not enrolled in {course.title}', 'warning')
        
        return redirect(url_for('student_courses'))

    @app.route('/student/grades')
    @login_required
    @student_required
    def student_grades():
        enrolled_courses = current_user.enrolled_courses
        grades = Grade.query.filter_by(student_id=current_user.id).all()
        
        # Group grades by course
        course_grades = {}
        for course in enrolled_courses:
            course_grades[course] = [g for g in grades if g.course_id == course.id]
        
        # Calculate course averages
        course_averages = {}
        for course, course_grades_list in course_grades.items():
            if course_grades_list:
                total_weighted_score = sum(g.score / g.max_score * g.weight for g in course_grades_list)
                total_weight = sum(g.weight for g in course_grades_list)
                if total_weight > 0:
                    course_averages[course.id] = (total_weighted_score / total_weight) * 100
                else:
                    course_averages[course.id] = 0
            else:
                course_averages[course.id] = 0
        
        return render_template('student/grades.html',
                             title='My Grades',
                             course_grades=course_grades,
                             course_averages=course_averages)

    @app.route('/student/attendance')
    @login_required
    @student_required
    def student_attendance():
        # Get all attendance records for the student
        attendance_records = (db.session.query(Attendance, AttendanceSession, Course)
                             .join(AttendanceSession)
                             .join(Course)
                             .filter(Attendance.student_id == current_user.id)
                             .order_by(AttendanceSession.date.desc())
                             .all())
        
        # Group by course
        attendance_by_course = {}
        for record, session, course in attendance_records:
            if course not in attendance_by_course:
                attendance_by_course[course] = []
            attendance_by_course[course].append((record, session))
        
        # Calculate attendance statistics
        attendance_stats = {
            'present': 0,
            'absent': 0,
            'excused': 0,
            'late': 0
        }
        for record, _, _ in attendance_records:
            attendance_stats[record.status] += 1
        
        return render_template('student/attendance.html',
                             title='My Attendance',
                             attendance_by_course=attendance_by_course,
                             attendance_stats=attendance_stats)

    @app.route('/student/profile', methods=['GET', 'POST'])
    @login_required
    def profile():
        form = ProfileForm()
        
        if form.validate_on_submit():
            # Check if username is being changed and is unique
            if form.username.data != current_user.username:
                user_exists = User.query.filter_by(username=form.username.data).first()
                if user_exists:
                    flash('That username is already taken.', 'danger')
                    return redirect(url_for('profile'))
            
            # Check if email is being changed and is unique
            if form.email.data != current_user.email:
                email_exists = User.query.filter_by(email=form.email.data).first()
                if email_exists:
                    flash('That email is already registered.', 'danger')
                    return redirect(url_for('profile'))
            
            # Update the user profile
            current_user.username = form.username.data
            current_user.email = form.email.data
            current_user.first_name = form.first_name.data
            current_user.last_name = form.last_name.data
            
            db.session.commit()
            flash('Your profile has been updated!', 'success')
            return redirect(url_for('profile'))
        
        # Pre-populate the form with current user data
        elif request.method == 'GET':
            form.username.data = current_user.username
            form.email.data = current_user.email
            form.first_name.data = current_user.first_name
            form.last_name.data = current_user.last_name
        
        # Password change form
        password_form = PasswordChangeForm()
        
        return render_template('student/profile.html', 
                             title='Profile',
                             form=form,
                             password_form=password_form)

    @app.route('/change-password', methods=['POST'])
    @login_required
    def change_password():
        form = PasswordChangeForm()
        
        if form.validate_on_submit():
            # Verify current password
            if current_user.check_password(form.current_password.data):
                current_user.set_password(form.new_password.data)
                db.session.commit()
                flash('Your password has been updated!', 'success')
            else:
                flash('Current password is incorrect.', 'danger')
        
        return redirect(url_for('profile'))

    # Teacher Routes
    @app.route('/teacher/students')
    @login_required
    @teacher_required
    def teacher_students():
        # Get courses taught by this teacher
        courses = Course.query.filter_by(teacher_id=current_user.id).all()
        
        # Get students enrolled in each course
        course_students = {}
        for course in courses:
            course_students[course] = course.enrolled_students
        
        return render_template('teacher/students.html',
                             title='My Students',
                             course_students=course_students)

    @app.route('/teacher/grades', methods=['GET', 'POST'])
    @login_required
    @teacher_required
    def teacher_grades():
        courses = Course.query.filter_by(teacher_id=current_user.id).all()
        
        # Initialize the form for adding a new grade
        form = GradeForm()
        
        # Populate the course dropdown with courses taught by this teacher
        form.course.choices = [(c.id, f"{c.code} - {c.title}") for c in courses]
        
        # Pre-select a course and populate student dropdown
        if courses:
            # Default to the first course if none is specified
            selected_course_id = request.args.get('course_id')
            if selected_course_id:
                selected_course = Course.query.get(int(selected_course_id))
                if selected_course and selected_course.teacher_id == current_user.id:
                    form.course.data = int(selected_course_id)
                    selected_course_obj = selected_course
                else:
                    selected_course_obj = courses[0]
                    form.course.data = courses[0].id
            else:
                selected_course_obj = courses[0]
                form.course.data = courses[0].id
                
            # Get students for the selected course
            enrolled_students = selected_course_obj.enrolled_students
            if enrolled_students:
                form.student.choices = [(s.id, f"{s.last_name}, {s.first_name}") for s in enrolled_students]
            else:
                form.student.choices = [(0, "No students enrolled in this course")]
        else:
            # If no courses are available
            form.student.choices = [(0, "No courses available")]
        
        # If a course is selected in POST, update student choices for that course
        if request.method == 'POST' and 'course' in request.form:
            course_id = int(request.form['course'])
            course = Course.query.get_or_404(course_id)
            
            # Update student dropdown
            if course.enrolled_students:
                form.student.choices = [(s.id, f"{s.last_name}, {s.first_name}") for s in course.enrolled_students]
            else:
                form.student.choices = [(0, "No students enrolled in this course")]
        
        # Handle form submission for adding a new grade
        if form.validate_on_submit():
            grade = Grade(
                student_id=form.student.data,
                course_id=form.course.data,
                assignment_name=form.assignment_name.data,
                score=form.score.data,
                max_score=form.max_score.data,
                weight=form.weight.data
            )
            
            db.session.add(grade)
            db.session.commit()
            
            # Create notification for the student
            create_notification(
                form.student.data, 
                f"A new grade has been added for {form.assignment_name.data} in {Course.query.get(form.course.data).title}"
            )
            
            flash('Grade added successfully!', 'success')
            return redirect(url_for('teacher_grades'))
        
        # Get all grades for courses taught by this teacher
        grades = (db.session.query(Grade, User, Course)
                 .join(User, Grade.student_id == User.id)
                 .join(Course, Grade.course_id == Course.id)
                 .filter(Course.teacher_id == current_user.id)
                 .order_by(Course.code, User.last_name, User.first_name, Grade.assignment_name)
                 .all())
        
        return render_template('teacher/grades.html',
                             title='Manage Grades',
                             grades=grades,
                             form=form)

    @app.route('/get_students/<int:course_id>')
    @login_required
    @teacher_required
    def get_students(course_id):
        course = Course.query.get_or_404(course_id)
        
        # Check if the teacher is authorized for this course
        if course.teacher_id != current_user.id and current_user.role != 'admin':
            return jsonify({'error': 'Unauthorized'}), 403
        
        students = [{'id': s.id, 'name': f"{s.last_name}, {s.first_name}"} for s in course.enrolled_students]
        return jsonify(students)

    @app.route('/teacher/attendance', methods=['GET', 'POST'])
    @login_required
    @teacher_required
    def teacher_attendance():
        # Get courses taught by this teacher
        courses = Course.query.filter_by(teacher_id=current_user.id).all()
        
        # Form for creating a new attendance session
        session_form = AttendanceSessionForm()
        session_form.course.choices = [(c.id, f"{c.code} - {c.title}") for c in courses]
        
        if session_form.validate_on_submit():
            # Create a new attendance session
            session = AttendanceSession(
                course_id=session_form.course.data,
                date=session_form.date.data,
                description=session_form.description.data
            )
            
            db.session.add(session)
            db.session.commit()
            
            # Create attendance records for all students enrolled in the course
            course = Course.query.get(session_form.course.data)
            for student in course.enrolled_students:
                attendance = Attendance(
                    session_id=session.id,
                    student_id=student.id,
                    status='present'  # Default status
                )
                db.session.add(attendance)
            
            db.session.commit()
            
            flash('Attendance session created successfully!', 'success')
            return redirect(url_for('teacher_attendance'))
        
        # Get all attendance sessions for courses taught by this teacher
        sessions = (db.session.query(AttendanceSession, Course)
                   .join(Course)
                   .filter(Course.teacher_id == current_user.id)
                   .order_by(AttendanceSession.date.desc())
                   .all())
        
        return render_template('teacher/attendance.html',
                             title='Manage Attendance',
                             sessions=sessions,
                             session_form=session_form)

    @app.route('/teacher/attendance/<int:session_id>', methods=['GET', 'POST'])
    @login_required
    @teacher_required
    def attendance_detail(session_id):
        session = AttendanceSession.query.get_or_404(session_id)
        course = session.course
        
        # Check if the teacher is authorized for this course
        if course.teacher_id != current_user.id and current_user.role != 'admin':
            flash('You are not authorized to view this attendance session.', 'danger')
            return redirect(url_for('teacher_attendance'))
        
        # Get all attendance records for this session
        records = (db.session.query(Attendance, User)
                  .join(User, Attendance.student_id == User.id)
                  .filter(Attendance.session_id == session_id)
                  .order_by(User.last_name, User.first_name)
                  .all())
        
        return render_template('teacher/attendance_detail.html',
                             title=f'Attendance for {course.code} - {session.date}',
                             session=session,
                             course=course,
                             records=records)

    @app.route('/teacher/attendance/update', methods=['POST'])
    @login_required
    @teacher_required
    def update_attendance():
        attendance_id = request.form.get('attendance_id')
        status = request.form.get('status')
        note = request.form.get('note', '')
        
        attendance = Attendance.query.get_or_404(attendance_id)
        
        # Check if the teacher is authorized for this attendance record
        session = attendance.session
        course = session.course
        if course.teacher_id != current_user.id and current_user.role != 'admin':
            return jsonify({'error': 'Unauthorized'}), 403
        
        # Update the attendance record
        attendance.status = status
        attendance.note = note
        db.session.commit()
        
        # If the status is 'absent', notify the student
        if status == 'absent':
            create_notification(
                attendance.student_id,
                f"You were marked absent for {course.code} on {session.date.strftime('%Y-%m-%d')}"
            )
        
        return jsonify({'success': True})

    # Admin Routes
    @app.route('/admin/users', methods=['GET'])
    @login_required
    @admin_required
    def admin_users():
        users = User.query.order_by(User.role, User.last_name, User.first_name).all()
        return render_template('admin/users.html', title='Manage Users', users=users)
        
    @app.route('/admin/user/edit/<int:user_id>', methods=['GET', 'POST'])
    @login_required
    @admin_required
    def edit_user(user_id):
        user = User.query.get_or_404(user_id)
        form = ProfileForm()
        
        if form.validate_on_submit():
            # Check if username is being changed and is unique
            if form.username.data != user.username:
                user_exists = User.query.filter_by(username=form.username.data).first()
                if user_exists:
                    flash('That username is already taken.', 'danger')
                    return redirect(url_for('edit_user', user_id=user_id))
            
            # Check if email is being changed and is unique
            if form.email.data != user.email:
                email_exists = User.query.filter_by(email=form.email.data).first()
                if email_exists:
                    flash('That email is already registered.', 'danger')
                    return redirect(url_for('edit_user', user_id=user_id))
            
            # Update the user profile
            user.username = form.username.data
            user.email = form.email.data
            user.first_name = form.first_name.data
            user.last_name = form.last_name.data
            
            db.session.commit()
            flash(f'User {user.get_full_name()} has been updated!', 'success')
            return redirect(url_for('admin_users'))
        
        # Pre-populate the form with user data
        elif request.method == 'GET':
            form.username.data = user.username
            form.email.data = user.email
            form.first_name.data = user.first_name
            form.last_name.data = user.last_name
        
        return render_template('admin/edit_user.html', 
                             title=f'Edit User {user.get_full_name()}',
                             form=form,
                             user=user)
                             
    @app.route('/admin/user/reset-password/<int:user_id>', methods=['GET', 'POST'])
    @login_required
    @admin_required
    def reset_user_password(user_id):
        user = User.query.get_or_404(user_id)
        form = AdminPasswordResetForm()
        
        if form.validate_on_submit():
            # Set the new password
            user.set_password(form.new_password.data)
            db.session.commit()
            
            # Create notification for the user
            create_notification(
                user.id,
                'Your password has been reset by an administrator. Please log in with your new password.'
            )
            
            flash(f'Password for {user.get_full_name()} has been reset.', 'success')
            return redirect(url_for('edit_user', user_id=user_id))
            
        return render_template('admin/reset_password.html',
                             title=f'Reset Password for {user.get_full_name()}',
                             form=form,
                             user=user)
                             
    @app.route('/admin/user/delete/<int:user_id>', methods=['POST'])
    @login_required
    @admin_required
    def delete_user(user_id):
        user = User.query.get_or_404(user_id)
        
        # Prevent deleting yourself
        if user.id == current_user.id:
            flash('You cannot delete your own account.', 'danger')
            return redirect(url_for('admin_users'))
        
        # Check if user is a teacher with courses
        if user.role == 'teacher' and user.courses_teaching:
            flash('This teacher is assigned to courses. Please reassign the courses before deleting the user.', 'danger')
            return redirect(url_for('admin_users'))
            
        # Get user information before deletion for confirmation message
        user_name = user.get_full_name()
        user_role = user.role
        
        # Handle student-specific deletions
        if user.role == 'student':
            # Delete all grades
            Grade.query.filter_by(student_id=user.id).delete()
            
            # Delete all attendance records
            Attendance.query.filter_by(student_id=user.id).delete()
            
            # Remove course enrollments
            user.enrolled_courses = []
        
        # Delete notifications
        Notification.query.filter_by(user_id=user.id).delete()
        
        # Delete the user
        db.session.delete(user)
        db.session.commit()
        
        flash(f'{user_role.capitalize()} {user_name} has been deleted.', 'success')
        return redirect(url_for('admin_users'))

    @app.route('/admin/courses', methods=['GET', 'POST'])
    @login_required
    @admin_required
    def admin_courses():
        form = CourseForm()
        
        # Populate teacher dropdown with all teachers
        teachers = User.query.filter_by(role='teacher').order_by(User.last_name, User.first_name).all()
        form.teacher.choices = [(0, 'None')] + [(t.id, f"{t.last_name}, {t.first_name}") for t in teachers]
        
        if form.validate_on_submit():
            teacher_id = form.teacher.data if form.teacher.data != 0 else None
            
            course = Course(
                code=form.code.data,
                title=form.title.data,
                description=form.description.data,
                credits=int(form.credits.data),
                teacher_id=teacher_id
            )
            
            db.session.add(course)
            db.session.commit()
            
            # If a teacher was assigned, notify them
            if teacher_id:
                create_notification(
                    teacher_id,
                    f"You have been assigned to teach {course.code} - {course.title}"
                )
            
            flash(f'Course {form.code.data} created successfully!', 'success')
            return redirect(url_for('admin_courses'))
        
        courses = Course.query.order_by(Course.code).all()
        return render_template('admin/courses.html', 
                             title='Manage Courses', 
                             courses=courses,
                             form=form)

    @app.route('/admin/course/edit/<int:course_id>', methods=['GET', 'POST'])
    @login_required
    @admin_required
    def edit_course(course_id):
        course = Course.query.get_or_404(course_id)
        form = CourseForm()
        
        # Populate teacher dropdown with all teachers
        teachers = User.query.filter_by(role='teacher').order_by(User.last_name, User.first_name).all()
        form.teacher.choices = [(0, 'None')] + [(t.id, f"{t.last_name}, {t.first_name}") for t in teachers]
        
        if form.validate_on_submit():
            # Check if the course code is being changed and is unique
            if form.code.data != course.code:
                code_exists = Course.query.filter_by(code=form.code.data).first()
                if code_exists:
                    flash('That course code is already taken.', 'danger')
                    return redirect(url_for('edit_course', course_id=course_id))
            
            # Update course information
            course.code = form.code.data
            course.title = form.title.data
            course.description = form.description.data
            course.credits = int(form.credits.data)
            
            # Update teacher if changed
            new_teacher_id = form.teacher.data if form.teacher.data != 0 else None
            old_teacher_id = course.teacher_id
            
            if new_teacher_id != old_teacher_id:
                course.teacher_id = new_teacher_id
                
                # Notify the old teacher if there was one
                if old_teacher_id:
                    create_notification(
                        old_teacher_id,
                        f"You are no longer assigned to teach {course.code} - {course.title}"
                    )
                
                # Notify the new teacher if there is one
                if new_teacher_id:
                    create_notification(
                        new_teacher_id,
                        f"You have been assigned to teach {course.code} - {course.title}"
                    )
            
            db.session.commit()
            flash(f'Course {form.code.data} updated successfully!', 'success')
            return redirect(url_for('admin_courses'))
        
        # Pre-populate the form with current course data
        elif request.method == 'GET':
            form.code.data = course.code
            form.title.data = course.title
            form.description.data = course.description
            form.credits.data = str(course.credits)
            form.teacher.data = course.teacher_id if course.teacher_id else 0
        
        return render_template('admin/edit_course.html',
                             title=f'Edit Course {course.code}',
                             form=form,
                             course=course)

    @app.route('/admin/course/delete/<int:course_id>', methods=['POST'])
    @login_required
    @admin_required
    def delete_course(course_id):
        course = Course.query.get_or_404(course_id)
        
        # Delete all associated records
        # Delete grades
        Grade.query.filter_by(course_id=course_id).delete()
        
        # Delete attendance sessions and records
        sessions = AttendanceSession.query.filter_by(course_id=course_id).all()
        for session in sessions:
            Attendance.query.filter_by(session_id=session.id).delete()
        AttendanceSession.query.filter_by(course_id=course_id).delete()
        
        # Remove course enrollments (from association table)
        course.enrolled_students = []
        
        # Delete the course
        db.session.delete(course)
        db.session.commit()
        
        flash(f'Course {course.code} has been deleted.', 'success')
        return redirect(url_for('admin_courses'))
        
    @app.route('/admin/enrollments', methods=['GET', 'POST'])
    @login_required
    @admin_required
    def admin_enrollments():
        form = AdminEnrollmentForm()
        
        # Get all available students and courses for the dropdown
        students = User.query.filter_by(role='student').order_by(User.last_name, User.first_name).all()
        courses = Course.query.order_by(Course.code).all()
        
        # Populate form dropdown choices
        form.student.choices = [(s.id, f"{s.last_name}, {s.first_name}") for s in students]
        form.course.choices = [(c.id, f"{c.code} - {c.title}") for c in courses]
        
        # Handle form submission
        if form.validate_on_submit():
            student = User.query.get_or_404(form.student.data)
            course = Course.query.get_or_404(form.course.data)
            
            # Check if student is already enrolled
            if course in student.enrolled_courses:
                flash(f'{student.get_full_name()} is already enrolled in {course.title}', 'warning')
            else:
                # Enroll the student
                student.enrolled_courses.append(course)
                db.session.commit()
                
                # Create notifications for both the student and teacher
                create_notification(
                    student.id,
                    f"You have been enrolled in {course.code} - {course.title} by an administrator"
                )
                
                if course.teacher_id:
                    create_notification(
                        course.teacher_id,
                        f"Student {student.get_full_name()} has been enrolled in your course {course.title} by an administrator"
                    )
                
                flash(f'Successfully enrolled {student.get_full_name()} in {course.title}', 'success')
                
                # Reset the form
                return redirect(url_for('admin_enrollments'))
        
        # Get all current enrollments for display
        enrollments = []
        for student in students:
            for course in student.enrolled_courses:
                enrollments.append({
                    'student': student,
                    'course': course
                })
                
        return render_template('admin/enrollments.html',
                               title='Manage Enrollments',
                               form=form,
                               enrollments=enrollments)
                               
    @app.route('/admin/enrollment/remove/<int:student_id>/<int:course_id>', methods=['POST'])
    @login_required
    @admin_required
    def remove_enrollment(student_id, course_id):
        student = User.query.get_or_404(student_id)
        course = Course.query.get_or_404(course_id)
        
        if course in student.enrolled_courses:
            # Remove the enrollment
            student.enrolled_courses.remove(course)
            db.session.commit()
            
            # Create notifications
            create_notification(
                student.id,
                f"You have been removed from {course.code} - {course.title} by an administrator"
            )
            
            if course.teacher_id:
                create_notification(
                    course.teacher_id,
                    f"Student {student.get_full_name()} has been removed from your course {course.title} by an administrator"
                )
            
            flash(f'Successfully removed {student.get_full_name()} from {course.title}', 'success')
        else:
            flash(f'{student.get_full_name()} is not enrolled in {course.title}', 'warning')
            
        return redirect(url_for('admin_enrollments'))

    # Notifications
    @app.route('/notifications')
    @login_required
    def notifications():
        # Get unread notifications for the current user
        unread_notifications = Notification.query.filter_by(
            user_id=current_user.id, 
            is_read=False
        ).order_by(Notification.timestamp.desc()).all()
        
        return jsonify([{
            'id': n.id,
            'message': n.message,
            'timestamp': n.timestamp.strftime('%Y-%m-%d %H:%M')
        } for n in unread_notifications])

    @app.route('/notifications/mark-read/<int:notification_id>', methods=['POST'])
    @login_required
    def mark_notification_read(notification_id):
        notification = Notification.query.get_or_404(notification_id)
        
        # Check if the notification belongs to the current user
        if notification.user_id != current_user.id:
            return jsonify({'error': 'Unauthorized'}), 403
        
        notification.is_read = True
        db.session.commit()
        
        return jsonify({'success': True})

    # Error Handlers
    @app.errorhandler(404)
    def not_found_error(error):
        return render_template('error.html', error_code=404, error_message='Page not found'), 404

    @app.errorhandler(403)
    def forbidden_error(error):
        return render_template('error.html', error_code=403, error_message='Forbidden'), 403

    @app.errorhandler(500)
    def internal_error(error):
        db.session.rollback()
        return render_template('error.html', error_code=500, error_message='Internal server error'), 500
